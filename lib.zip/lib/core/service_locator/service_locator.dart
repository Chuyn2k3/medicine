import 'package:get_it/get_it.dart';

import '../../data/datasources/api_client.dart';
import '../../data/repositories/chat_repository.dart';
import '../../data/repositories/medicine_repository.dart';
import '../../data/repositories/prescription_repository.dart';
import '../../data/repositories/schedule_repository.dart';
import '../../presentation/cubits/chat_cubit.dart';
import '../../presentation/cubits/medicine_cubit.dart';
import '../../presentation/cubits/prescription_cubit.dart';
import '../../presentation/cubits/schedule_cubit.dart';

final getIt = GetIt.instance;

/// Setup dependency injection with GetIt
void setupServiceLocator() {
  // DataSources
  getIt.registerSingleton<ApiClient>(ApiClient());

  // Repositories
  getIt.registerSingleton<MedicineRepository>(
    MedicineRepository(getIt<ApiClient>()),
  );
  getIt.registerSingleton<PrescriptionRepository>(
    PrescriptionRepository(getIt<ApiClient>()),
  );
  getIt.registerSingleton<ScheduleRepository>(
    ScheduleRepository(getIt<ApiClient>()),
  );
  getIt.registerSingleton<ChatRepository>(
    ChatRepository(getIt<ApiClient>()),
  );

  // Cubits
  getIt.registerSingleton<MedicineCubit>(
    MedicineCubit(getIt<MedicineRepository>()),
  );
  getIt.registerSingleton<PrescriptionCubit>(
    PrescriptionCubit(getIt<PrescriptionRepository>()),
  );
  getIt.registerSingleton<ScheduleCubit>(
    ScheduleCubit(getIt<ScheduleRepository>()),
  );
  getIt.registerSingleton<ChatCubit>(
    ChatCubit(getIt<ChatRepository>()),
  );
}
