part of 'prescription_cubit.dart';

abstract class PrescriptionState {
  const PrescriptionState();
}

class PrescriptionInitial extends PrescriptionState {}

class PrescriptionLoading extends PrescriptionState {}

class PrescriptionListLoaded extends PrescriptionState {
  final List<PrescriptionModel> prescriptions;

  PrescriptionListLoaded(this.prescriptions);
}

class PrescriptionDetailLoaded extends PrescriptionState {
  final PrescriptionModel prescription;

  PrescriptionDetailLoaded(this.prescription);
}

class PrescriptionError extends PrescriptionState {
  final String message;

  const PrescriptionError(this.message);
}
