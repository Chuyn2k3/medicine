import 'package:bloc/bloc.dart';

import '../../data/models/medicine_model.dart';
import '../../data/repositories/medicine_repository.dart';

part 'medicine_state.dart';

class MedicineCubit extends Cubit<MedicineState> {
  final MedicineRepository _repository;

  MedicineCubit(this._repository) : super(MedicineInitial());

  Future<void> getMedicineList() async {
    try {
      emit(MedicineLoading());
      final medicines = await _repository.getMedicineList();
      emit(MedicineListLoaded(medicines));
    } catch (e) {
      emit(MedicineError(e.toString()));
    }
  }

  Future<void> getMedicineByBarcode(String barcode) async {
    try {
      emit(MedicineLoading());
      final medicine = await _repository.getMedicineByBarcode(barcode);
      if (medicine != null) {
        emit(MedicineDetailLoaded(medicine));
      } else {
        emit(const MedicineError('Thuốc không tìm thấy'));
      }
    } catch (e) {
      emit(MedicineError(e.toString()));
    }
  }

  Future<void> getMedicineById(String id) async {
    try {
      emit(MedicineLoading());
      final medicine = await _repository.getMedicineById(id);
      if (medicine != null) {
        emit(MedicineDetailLoaded(medicine));
      } else {
        emit(const MedicineError('Thuốc không tìm thấy'));
      }
    } catch (e) {
      emit(MedicineError(e.toString()));
    }
  }
}
