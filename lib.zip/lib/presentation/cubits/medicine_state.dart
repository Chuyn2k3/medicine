part of 'medicine_cubit.dart';

abstract class MedicineState {
  const MedicineState();
}

class MedicineInitial extends MedicineState {}

class MedicineLoading extends MedicineState {}

class MedicineListLoaded extends MedicineState {
  final List<MedicineModel> medicines;

  MedicineListLoaded(this.medicines);
}

class MedicineDetailLoaded extends MedicineState {
  final MedicineModel medicine;

  MedicineDetailLoaded(this.medicine);
}

class MedicineError extends MedicineState {
  final String message;

  const MedicineError(this.message);
}
