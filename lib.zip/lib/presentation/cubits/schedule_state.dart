part of 'schedule_cubit.dart';

abstract class ScheduleState {
  const ScheduleState();
}

class ScheduleInitial extends ScheduleState {}

class ScheduleLoading extends ScheduleState {}

class ScheduleListLoaded extends ScheduleState {
  final List<ScheduleModel> schedules;

  ScheduleListLoaded(this.schedules);
}

class ScheduleCreated extends ScheduleState {
  final ScheduleModel schedule;

  ScheduleCreated(this.schedule);
}

class ScheduleUpdated extends ScheduleState {
  final ScheduleModel schedule;

  ScheduleUpdated(this.schedule);
}

class ScheduleDeleted extends ScheduleState {}

class ScheduleError extends ScheduleState {
  final String message;

  const ScheduleError(this.message);
}
