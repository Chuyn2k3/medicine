import 'package:bloc/bloc.dart';
import '../../data/models/prescription_model.dart';
import '../../data/repositories/prescription_repository.dart';

part 'prescription_state.dart';

class PrescriptionCubit extends Cubit<PrescriptionState> {
  final PrescriptionRepository _repository;

  PrescriptionCubit(this._repository) : super(PrescriptionInitial());

  Future<void> getPrescriptionList() async {
    try {
      emit(PrescriptionLoading());
      final prescriptions = await _repository.getPrescriptionList();
      emit(PrescriptionListLoaded(prescriptions));
    } catch (e) {
      emit(PrescriptionError(e.toString()));
    }
  }

  Future<void> getPrescriptionByCode(String code) async {
    try {
      emit(PrescriptionLoading());
      final prescription = await _repository.getPrescriptionByCode(code);
      if (prescription != null) {
        emit(PrescriptionDetailLoaded(prescription));
      } else {
        emit(const PrescriptionError('Đơn thuốc không tìm thấy'));
      }
    } catch (e) {
      emit(PrescriptionError(e.toString()));
    }
  }

  Future<void> getPrescriptionById(String id) async {
    try {
      emit(PrescriptionLoading());
      final prescription = await _repository.getPrescriptionById(id);
      if (prescription != null) {
        emit(PrescriptionDetailLoaded(prescription));
      } else {
        emit(const PrescriptionError('Đơn thuốc không tìm thấy'));
      }
    } catch (e) {
      emit(PrescriptionError(e.toString()));
    }
  }
}
