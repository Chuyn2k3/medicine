import 'package:bloc/bloc.dart';

import '../../data/models/chat_message_model.dart';
import '../../data/repositories/chat_repository.dart';

part 'chat_state.dart';

class ChatCubit extends Cubit<ChatState> {
  final ChatRepository _repository;

  ChatCubit(this._repository) : super(ChatInitial());

  Future<void> loadChatHistory() async {
    try {
      emit(ChatLoading());
      final messages = await _repository.getChatHistory();
      emit(ChatLoaded(messages));
    } catch (e) {
      emit(ChatError(e.toString()));
    }
  }

  Future<void> sendMessage(String message) async {
    try {
      final response = await _repository.sendMessage(message);
      if (response != null) {
        final currentState = state;
        if (currentState is ChatLoaded) {
          emit(ChatLoaded([...currentState.messages, response]));
        } else {
          emit(ChatLoaded([response]));
        }
      }
    } catch (e) {
      emit(ChatError(e.toString()));
    }
  }
}
