import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../core/theme/app_colors.dart';
import '../cubits/schedule_cubit.dart';
import '../widgets/schedule_item.dart';
import 'add_schedule_page.dart';

class SchedulePage extends StatefulWidget {
  const SchedulePage({Key? key}) : super(key: key);

  @override
  State<SchedulePage> createState() => _SchedulePageState();
}

class _SchedulePageState extends State<SchedulePage> {
  @override
  void initState() {
    super.initState();
    Future.microtask(
      () => context.read<ScheduleCubit>().getScheduleList(),
    );
  }

  void _navigateToAddSchedule() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => const AddSchedulePage()),
    ).then((_) {
      context.read<ScheduleCubit>().getScheduleList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Lịch Uống Thuốc'),
        backgroundColor: AppColors.accent,
        foregroundColor: AppColors.white,
        actions: [
          IconButton(
            icon: const Icon(Icons.add),
            onPressed: _navigateToAddSchedule,
          ),
        ],
      ),
      body: BlocBuilder<ScheduleCubit, ScheduleState>(
        builder: (context, state) {
          if (state is ScheduleLoading) {
            return const Center(child: CircularProgressIndicator());
          }

          if (state is ScheduleListLoaded) {
            final schedules = state.schedules;
            if (schedules.isEmpty) {
              return _buildEmptyState(context);
            }
            return ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: schedules.length,
              itemBuilder: (context, index) {
                return ScheduleItem(
                  schedule: schedules[index],
                  onDelete: () {
                    context
                        .read<ScheduleCubit>()
                        .deleteSchedule(schedules[index].id);
                  },
                );
              },
            );
          }

          if (state is ScheduleError) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.error_outline,
                    size: 64,
                    color: AppColors.grey300,
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'Lỗi: ${state.message}',
                    style: Theme.of(context).textTheme.bodyMedium,
                  ),
                  const SizedBox(height: 24),
                  ElevatedButton(
                    onPressed: () =>
                        context.read<ScheduleCubit>().getScheduleList(),
                    child: const Text('Thử Lại'),
                  ),
                ],
              ),
            );
          }

          return _buildEmptyState(context);
        },
      ),
    );
  }

  Widget _buildEmptyState(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.schedule,
            size: 64,
            color: AppColors.grey300,
          ),
          const SizedBox(height: 16),
          Text(
            'Chưa có lịch uống thuốc',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: AppColors.grey400,
                ),
          ),
          const SizedBox(height: 24),
          ElevatedButton.icon(
            onPressed: _navigateToAddSchedule,
            icon: const Icon(Icons.add),
            label: const Text('Thêm Lịch'),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.accent,
            ),
          ),
        ],
      ),
    );
  }
}
