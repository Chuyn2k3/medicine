import 'dart:convert';
import 'dart:developer' as developer;
import 'package:dio/dio.dart';
import '../../core/constants/app_constants.dart';
import '../models/chat_message_model.dart';
import '../models/medicine_model.dart';
import '../models/prescription_model.dart';
import '../models/schedule_model.dart';

class ApiClient {
  late Dio _dio;

  ApiClient() {
    _dio = Dio(
      BaseOptions(
        baseUrl: AppConstants.baseUrl,
        connectTimeout:
            const Duration(milliseconds: AppConstants.connectTimeout),
        receiveTimeout:
            const Duration(milliseconds: AppConstants.receiveTimeout),
        contentType: Headers.jsonContentType,
      ),
    );

    _dio.interceptors.add(
      InterceptorsWrapper(
        onRequest: (options, handler) {
          _logRequest(options);
          return handler.next(options);
        },
        onResponse: (response, handler) {
          _logResponse(response);
          return handler.next(response);
        },
        onError: (error, handler) {
          _logError(error);
          return handler.next(error);
        },
      ),
    );
  }

  /// Log detailed request information
  void _logRequest(RequestOptions options) {
    developer.log(
      '''
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🔵 API REQUEST
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Method: ${options.method}
Path: ${options.path}
Full URL: ${options.uri}

Headers:
${_formatHeaders(options.headers)}

Query Parameters:
${options.queryParameters.isEmpty ? 'None' : _formatMap(options.queryParameters)}

Body/Data:
${options.data is FormData ? 'FormData' : _formatJson(options.data)}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
''',
      name: 'ApiClient',
      level: 800, // INFO level
    );
  }

  /// Log detailed response information
  void _logResponse(Response response) {
    developer.log(
      '''
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🟢 API RESPONSE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Status Code: ${response.statusCode}
Path: ${response.requestOptions.path}

Response Headers:
${_formatHeaders(response.headers.map)}

Response Body:
${_formatJson(response.data)}

Time: ${DateTime.now()}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
''',
      name: 'ApiClient',
      level: 800,
    );
  }

  /// Log error information
  void _logError(DioException error) {
    developer.log(
      '''
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🔴 API ERROR
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Error Type: ${error.type}
Status Code: ${error.response?.statusCode ?? 'N/A'}
Path: ${error.requestOptions.path}
Message: ${error.message}

Error Details:
${error.error}

Response:
${_formatJson(error.response?.data)}

Time: ${DateTime.now()}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
''',
      name: 'ApiClient',
      level: 1000, // ERROR level
    );
  }

  /// Format headers for display
  String _formatHeaders(Map<String, dynamic> headers) {
    if (headers.isEmpty) return 'None';
    return headers.entries
        .map((e) => '  ${e.key}: ${e.value}')
        .join('\n');
  }

  /// Format map to readable string
  String _formatMap(Map<String, dynamic> map) {
    return map.entries
        .map((e) => '  ${e.key}: ${e.value}')
        .join('\n');
  }

  /// Format JSON for display
  String _formatJson(dynamic data) {
    if (data == null) return 'null';
    if (data is String) return data;
    if (data is Map || data is List) {
      try {
        return const JsonEncoder.withIndent('  ').convert(data);
      } catch (_) {
        return data.toString();
      }
    }
    return data.toString();
  }

  // Medicine APIs
  Future<List<MedicineModel>> getMedicineList() async {
    try {
      final response = await _dio.get('/medicines');
      final List<dynamic> data = response.data['data'];
      return data.map((json) => MedicineModel.fromJson(json)).toList();
    } catch (e) {
      rethrow;
    }
  }

  Future<MedicineModel> getMedicineByBarcode(String barcode) async {
    try {
      final response = await _dio.get('/medicines/barcode/$barcode');
      return MedicineModel.fromJson(response.data['data']);
    } catch (e) {
      rethrow;
    }
  }

  Future<MedicineModel> getMedicineById(String id) async {
    try {
      final response = await _dio.get('/medicines/$id');
      return MedicineModel.fromJson(response.data['data']);
    } catch (e) {
      rethrow;
    }
  }

  // Prescription APIs
  Future<List<PrescriptionModel>> getPrescriptionList() async {
    try {
      final response = await _dio.get('/prescriptions');
      final List<dynamic> data = response.data['data'];
      return data.map((json) => PrescriptionModel.fromJson(json)).toList();
    } catch (e) {
      rethrow;
    }
  }

  Future<PrescriptionModel> getPrescriptionByCode(String code) async {
    try {
      final response = await _dio.get('/prescriptions/code/$code');
      return PrescriptionModel.fromJson(response.data['data']);
    } catch (e) {
      rethrow;
    }
  }

  Future<PrescriptionModel> getPrescriptionById(String id) async {
    try {
      final response = await _dio.get('/prescriptions/$id');
      return PrescriptionModel.fromJson(response.data['data']);
    } catch (e) {
      rethrow;
    }
  }

  // Schedule APIs
  Future<List<ScheduleModel>> getScheduleList() async {
    try {
      final response = await _dio.get('/schedules');
      final List<dynamic> data = response.data['data'];
      return data.map((json) => ScheduleModel.fromJson(json)).toList();
    } catch (e) {
      rethrow;
    }
  }

  Future<ScheduleModel> createSchedule(ScheduleModel schedule) async {
    try {
      final response = await _dio.post('/schedules', data: schedule.toJson());
      return ScheduleModel.fromJson(response.data['data']);
    } catch (e) {
      rethrow;
    }
  }

  Future<ScheduleModel> updateSchedule(
      String id, ScheduleModel schedule) async {
    try {
      final response =
          await _dio.put('/schedules/$id', data: schedule.toJson());
      return ScheduleModel.fromJson(response.data['data']);
    } catch (e) {
      rethrow;
    }
  }

  Future<void> deleteSchedule(String id) async {
    try {
      await _dio.delete('/schedules/$id');
    } catch (e) {
      rethrow;
    }
  }

  // Chat APIs
  Future<ChatMessageModel> sendChatMessage(String message) async {
    try {
      final response = await _dio.post(
        '/chat/message',
        data: {'message': message},
      );
      return ChatMessageModel.fromJson(response.data['data']);
    } catch (e) {
      rethrow;
    }
  }

  Future<List<ChatMessageModel>> getChatHistory() async {
    try {
      final response = await _dio.get('/chat/history');
      final List<dynamic> data = response.data['data'];
      return data.map((json) => ChatMessageModel.fromJson(json)).toList();
    } catch (e) {
      rethrow;
    }
  }
}

