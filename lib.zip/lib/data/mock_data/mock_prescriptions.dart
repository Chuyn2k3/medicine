import 'package:medical_drug/data/models/prescription_model.dart';

final mockPrescriptions = [
  PrescriptionModel(
    id: '1',
    prescriptionCode: 'RX001',
    patientName: 'Nguyễn Văn A',
    doctorName: 'TS. Trần Văn B',
    date: DateTime(2024, 11, 10),
    medicines: [
      PrescriptionItem(
        medicineId: '1',
        medicineName: 'Paracetamol 500mg',
        dosage: '500mg',
        quantity: 10,
        instructions: 'Uống 1-2 viên mỗi 4-6 giờ, tối đa 3 ngày',
      ),
      PrescriptionItem(
        medicineId: '2',
        medicineName: 'Amoxicillin 250mg',
        dosage: '250mg',
        quantity: 12,
        instructions: 'Uống 1 viên mỗi 8 giờ, 7 ngày liên tiếp',
      ),
    ],
    notes: 'Uống sau ăn, uống đủ nước',
  ),
  PrescriptionModel(
    id: '2',
    prescriptionCode: 'RX002',
    patientName: 'Trần Thị C',
    doctorName: 'TS. Lê Văn D',
    date: DateTime(2024, 11, 8),
    medicines: [
      PrescriptionItem(
        medicineId: '3',
        medicineName: 'Vitamin C 1000mg',
        dosage: '1000mg',
        quantity: 30,
        instructions: 'Uống 1 viên mỗi sáng, 30 ngày',
      ),
    ],
    notes: 'Bổ sung vitamin, tăng miễn dịch',
  ),
];

// class PrescriptionItem {
//   final String medicineId;
//   final String medicineName;
//   final String dosage;
//   final int quantity;
//   final String instructions;
//
//   PrescriptionItem({
//     required this.medicineId,
//     required this.medicineName,
//     required this.dosage,
//     required this.quantity,
//     required this.instructions,
//   });
// }
