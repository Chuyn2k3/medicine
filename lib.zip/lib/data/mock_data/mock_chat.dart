import '../models/chat_message_model.dart';

final mockChatMessages = [
  ChatMessageModel(
    id: '1',
    message:
        'Xin chào! Tôi là trợ lý AI y tế. Tôi có thể giúp bạn về thông tin thuốc, liều dùng, tác dụng phụ...',
    isUser: false,
    timestamp: DateTime.now().subtract(const Duration(hours: 1)),
  ),
  ChatMessageModel(
    id: '2',
    message: 'Paracetamol có tác dụng gì?',
    isUser: true,
    timestamp: DateTime.now().subtract(const Duration(minutes: 45)),
  ),
  ChatMessageModel(
    id: '3',
    message:
        'Paracetamol là một loại thuốc hạ sốt và giảm đau thường được sử dụng để điều trị sốt cao, đau đầu, đau cơ thể. Tác dụng: Hạ sốt, giảm đau nhẹ đến vừa phải. Liều dùng: Thường 500-1000mg mỗi 4-6 giờ, tối đa 4g/ngày.',
    isUser: false,
    timestamp: DateTime.now().subtract(const Duration(minutes: 40)),
  ),
];
