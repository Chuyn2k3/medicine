// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'medicine_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

MedicineModel _$MedicineModelFromJson(Map<String, dynamic> json) =>
    MedicineModel(
      id: json['id'] as String,
      name: json['name'] as String,
      barcode: json['barcode'] as String,
      dosage: json['dosage'] as String,
      description: json['description'] as String,
      ingredients: (json['ingredients'] as List<dynamic>)
          .map((e) => e as String)
          .toList(),
      sideEffects: json['sideEffects'] as String,
      usage: json['usage'] as String,
      manufacturer: json['manufacturer'] as String,
      price: (json['price'] as num).toDouble(),
      expiryDate: json['expiryDate'] as String,
    );

Map<String, dynamic> _$MedicineModelToJson(MedicineModel instance) =>
    <String, dynamic>{
      'id': instance.id,
      'name': instance.name,
      'barcode': instance.barcode,
      'dosage': instance.dosage,
      'description': instance.description,
      'ingredients': instance.ingredients,
      'sideEffects': instance.sideEffects,
      'usage': instance.usage,
      'manufacturer': instance.manufacturer,
      'price': instance.price,
      'expiryDate': instance.expiryDate,
    };
