// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'prescription_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

PrescriptionModel _$PrescriptionModelFromJson(Map<String, dynamic> json) =>
    PrescriptionModel(
      id: json['id'] as String,
      prescriptionCode: json['prescriptionCode'] as String,
      patientName: json['patientName'] as String,
      doctorName: json['doctorName'] as String,
      date: DateTime.parse(json['date'] as String),
      medicines: (json['medicines'] as List<dynamic>)
          .map((e) => PrescriptionItem.fromJson(e as Map<String, dynamic>))
          .toList(),
      notes: json['notes'] as String,
    );

Map<String, dynamic> _$PrescriptionModelToJson(PrescriptionModel instance) =>
    <String, dynamic>{
      'id': instance.id,
      'prescriptionCode': instance.prescriptionCode,
      'patientName': instance.patientName,
      'doctorName': instance.doctorName,
      'date': instance.date.toIso8601String(),
      'medicines': instance.medicines,
      'notes': instance.notes,
    };

PrescriptionItem _$PrescriptionItemFromJson(Map<String, dynamic> json) =>
    PrescriptionItem(
      medicineId: json['medicineId'] as String,
      medicineName: json['medicineName'] as String,
      dosage: json['dosage'] as String,
      quantity: (json['quantity'] as num).toInt(),
      instructions: json['instructions'] as String,
    );

Map<String, dynamic> _$PrescriptionItemToJson(PrescriptionItem instance) =>
    <String, dynamic>{
      'medicineId': instance.medicineId,
      'medicineName': instance.medicineName,
      'dosage': instance.dosage,
      'quantity': instance.quantity,
      'instructions': instance.instructions,
    };
