import 'package:json_annotation/json_annotation.dart';

part 'medicine_model.g.dart';

@JsonSerializable()
class MedicineModel {
  final String id;
  final String name;
  final String barcode;
  final String dosage;
  final String description;
  final List<String> ingredients;
  final String sideEffects;
  final String usage;
  final String manufacturer;
  final double price;
  final String expiryDate;

  MedicineModel({
    required this.id,
    required this.name,
    required this.barcode,
    required this.dosage,
    required this.description,
    required this.ingredients,
    required this.sideEffects,
    required this.usage,
    required this.manufacturer,
    required this.price,
    required this.expiryDate,
  });

  factory MedicineModel.fromJson(Map<String, dynamic> json) =>
      _$MedicineModelFromJson(json);
  Map<String, dynamic> toJson() => _$MedicineModelToJson(this);
}
