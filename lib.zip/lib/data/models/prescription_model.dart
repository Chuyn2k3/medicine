import 'package:json_annotation/json_annotation.dart';

part 'prescription_model.g.dart';

@JsonSerializable()
class PrescriptionModel {
  final String id;
  final String prescriptionCode;
  final String patientName;
  final String doctorName;
  final DateTime date;
  final List<PrescriptionItem> medicines;
  final String notes;

  PrescriptionModel({
    required this.id,
    required this.prescriptionCode,
    required this.patientName,
    required this.doctorName,
    required this.date,
    required this.medicines,
    required this.notes,
  });

  factory PrescriptionModel.fromJson(Map<String, dynamic> json) =>
      _$PrescriptionModelFromJson(json);
  Map<String, dynamic> toJson() => _$PrescriptionModelToJson(this);
}

@JsonSerializable()
class PrescriptionItem {
  final String medicineId;
  final String medicineName;
  final String dosage;
  final int quantity;
  final String instructions;

  PrescriptionItem({
    required this.medicineId,
    required this.medicineName,
    required this.dosage,
    required this.quantity,
    required this.instructions,
  });

  factory PrescriptionItem.fromJson(Map<String, dynamic> json) =>
      _$PrescriptionItemFromJson(json);
  Map<String, dynamic> toJson() => _$PrescriptionItemToJson(this);
}
