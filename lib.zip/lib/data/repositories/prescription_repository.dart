import '../datasources/api_client.dart';
import '../mock_data/mock_prescriptions.dart';
import '../models/prescription_model.dart';

class PrescriptionRepository {
  final ApiClient _apiClient;

  PrescriptionRepository(this._apiClient);

  Future<List<PrescriptionModel>> getPrescriptionList() async {
    try {
      return await _apiClient.getPrescriptionList();
    } catch (e) {
      // Return mock data on error
      return mockPrescriptions;
    }
  }

  Future<PrescriptionModel?> getPrescriptionByCode(String code) async {
    try {
      return await _apiClient.getPrescriptionByCode(code);
    } catch (e) {
      // Return mock data on error
      return mockPrescriptions.firstWhere(
        (p) => p.prescriptionCode == code,
      );
    }
  }

  Future<PrescriptionModel?> getPrescriptionById(String id) async {
    try {
      return await _apiClient.getPrescriptionById(id);
    } catch (e) {
      // Return mock data on error
      return mockPrescriptions.firstWhere(
        (p) => p.id == id,
      );
    }
  }
}
