import '../datasources/api_client.dart';
import '../mock_data/mock_chat.dart';
import '../models/chat_message_model.dart';

class ChatRepository {
  final ApiClient _apiClient;

  ChatRepository(this._apiClient);

  Future<List<ChatMessageModel>> getChatHistory() async {
    try {
      return await _apiClient.getChatHistory();
    } catch (e) {
      // Return mock data on error
      return mockChatMessages;
    }
  }

  Future<ChatMessageModel?> sendMessage(String message) async {
    try {
      final response = await _apiClient.sendChatMessage(message);
      mockChatMessages.add(response);
      return response;
    } catch (e) {
      // Create mock response on error
      final mockResponse = ChatMessageModel(
        id: DateTime.now().toString(),
        message:
            'Xin lỗi, tôi không thể trả lời ngay bây giờ. Vui lòng thử lại!',
        isUser: false,
        timestamp: DateTime.now(),
      );
      mockChatMessages.add(mockResponse);
      return mockResponse;
    }
  }
}
