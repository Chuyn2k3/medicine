import '../datasources/api_client.dart';
import '../mock_data/mock_schedules.dart';
import '../models/schedule_model.dart';

class ScheduleRepository {
  final ApiClient _apiClient;

  ScheduleRepository(this._apiClient);

  Future<List<ScheduleModel>> getScheduleList() async {
    try {
      return await _apiClient.getScheduleList();
    } catch (e) {
      // Return mock data on error
      return mockSchedules;
    }
  }

  Future<ScheduleModel?> createSchedule(ScheduleModel schedule) async {
    try {
      return await _apiClient.createSchedule(schedule);
    } catch (e) {
      // Add to mock data on error
      mockSchedules.add(schedule);
      return schedule;
    }
  }

  Future<ScheduleModel?> updateSchedule(
      String id, ScheduleModel schedule) async {
    try {
      return await _apiClient.updateSchedule(id, schedule);
    } catch (e) {
      // Update mock data on error
      final index = mockSchedules.indexWhere((s) => s.id == id);
      if (index != -1) {
        mockSchedules[index] = schedule;
      }
      return schedule;
    }
  }

  Future<void> deleteSchedule(String id) async {
    try {
      await _apiClient.deleteSchedule(id);
    } catch (e) {
      // Remove from mock data on error
      mockSchedules.removeWhere((s) => s.id == id);
    }
  }
}
