import '../datasources/api_client.dart';
import '../mock_data/mock_medicines.dart';
import '../models/medicine_model.dart';

class MedicineRepository {
  final ApiClient _apiClient;

  MedicineRepository(this._apiClient);

  Future<List<MedicineModel>> getMedicineList() async {
    try {
      return await _apiClient.getMedicineList();
    } catch (e) {
      // Return mock data on error
      return mockMedicines;
    }
  }

  Future<MedicineModel?> getMedicineByBarcode(String barcode) async {
    try {
      return await _apiClient.getMedicineByBarcode(barcode);
    } catch (e) {
      // Return mock data on error
      return mockMedicines.firstWhere(
        (m) => m.barcode == barcode,
        orElse: () => MedicineModel(
          id: '0',
          name: 'Not Found',
          barcode: barcode,
          dosage: '',
          description: '',
          ingredients: [],
          sideEffects: '',
          usage: '',
          manufacturer: '',
          price: 0,
          expiryDate: '',
        ),
      );
    }
  }

  Future<MedicineModel?> getMedicineById(String id) async {
    try {
      return await _apiClient.getMedicineById(id);
    } catch (e) {
      // Return mock data on error
      return mockMedicines.firstWhere(
        (m) => m.id == id,
      );
    }
  }
}
