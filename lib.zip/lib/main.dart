import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:medical_drug/presentation/cubits/chat_cubit.dart';
import 'package:medical_drug/presentation/cubits/medicine_cubit.dart';
import 'package:medical_drug/presentation/cubits/prescription_cubit.dart';
import 'package:medical_drug/presentation/cubits/schedule_cubit.dart';
import 'package:medical_drug/presentation/pages/home_page.dart';

import 'core/service_locator/service_locator.dart';
import 'core/theme/app_theme.dart';

void main() {
  setupServiceLocator();
  runApp(const MedicineApp());
}

class MedicineApp extends StatelessWidget {
  const MedicineApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider<MedicineCubit>(
          create: (context) => getIt<MedicineCubit>(),
        ),
        BlocProvider<PrescriptionCubit>(
          create: (context) => getIt<PrescriptionCubit>(),
        ),
        BlocProvider<ScheduleCubit>(
          create: (context) => getIt<ScheduleCubit>(),
        ),
        BlocProvider<ChatCubit>(
          create: (context) => getIt<ChatCubit>(),
        ),
      ],
      child: MaterialApp(
        title: 'Medicine App',
        theme: AppTheme.lightTheme,
        home: const HomePage(),
        debugShowCheckedModeBanner: false,
      ),
    );
  }
}
